namespace ViewModel_Fun
{
    public class Message
    {
        public string NewMessage {get;set;}
    }
}