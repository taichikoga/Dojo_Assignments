namespace ViewModel_Fun
{
    public class Numbers
    {
        public int Num {get;set;}
    }
}