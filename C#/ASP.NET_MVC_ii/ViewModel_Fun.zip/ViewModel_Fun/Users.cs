namespace ViewModel_Fun
{
    public class Users
    {
        public string Name {get;set;}
    }
}