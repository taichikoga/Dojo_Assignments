namespace Assignment_Deck_of_Cards
{
    public class Card
    {
        public string stringVal { get; set; }
        public string suit { get; set; }
        public int val { get; set; }
    }
}