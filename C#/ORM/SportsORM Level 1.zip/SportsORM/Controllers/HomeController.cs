﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.WomensLeagues = context.Leagues
                .Where(w => w.Name.Contains("Women"));

            ViewBag.HockeyLeagues = context.Leagues
                .Where(h => h.Sport.Contains("Hockey"));

            ViewBag.NonFootballLeagues = context.Leagues
                .Where(n => !n.Sport.Contains("Football"));

            ViewBag.ConferenceLeagues = context.Leagues
                .Where(c => c.Name.Contains("Conference"));

            ViewBag.AtlanticLeagues = context.Leagues
                .Where(a => a.Name.Contains("Atlantic"));

            ViewBag.DallasTeams = context.Teams
                .Where(d => d.Location.Contains("Dallas"));

            ViewBag.RaptorTeams = context.Teams
                .Where(r => r.TeamName.Contains("Raptors"));

            ViewBag.CityLocations = context.Teams
                .Where(l => l.Location.Contains("City"));

            ViewBag.TCityTeams = context.Teams
                .Where(t => t.TeamName.StartsWith("T"));

            ViewBag.AllTeamsSortedAZ = context.Teams
                .OrderBy(a => a.TeamName);

            ViewBag.AllTeamsSortedZA = context.Teams
                .OrderByDescending(a => a.TeamName);

            ViewBag.LastNameCooper = context.Players
                .Where(a => a.LastName.Contains("Cooper"));

            ViewBag.FirstNameJoshua = context.Players
                .Where(a => a.FirstName.Contains("Joshua"));

            ViewBag.LastNameCooperFirstNameNotJoshua = context.Players
                .Where(a => a.LastName.Contains("Cooper"))
                .Where(b => !b.FirstName.Contains("Joshua"));

            ViewBag.FirstNameOr = context.Players
                .Where(a => a.FirstName.Contains("Alexander") || a.FirstName.Contains("Wyatt"));

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}