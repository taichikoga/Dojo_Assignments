﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.WomensLeagues = context.Leagues
                .Where(w => w.Name.Contains("Women"));

            ViewBag.HockeyLeagues = context.Leagues
                .Where(h => h.Sport.Contains("Hockey"));

            ViewBag.NonFootballLeagues = context.Leagues
                .Where(n => !n.Sport.Contains("Football"));

            ViewBag.ConferenceLeagues = context.Leagues
                .Where(c => c.Name.Contains("Conference"));

            ViewBag.AtlanticLeagues = context.Leagues
                .Where(a => a.Name.Contains("Atlantic"));

            ViewBag.DallasTeams = context.Teams
                .Where(d => d.Location.Contains("Dallas"));

            ViewBag.RaptorTeams = context.Teams
                .Where(r => r.TeamName.Contains("Raptors"));

            ViewBag.CityLocations = context.Teams
                .Where(l => l.Location.Contains("City"));

            ViewBag.TCityTeams = context.Teams
                .Where(t => t.TeamName.StartsWith("T"));

            ViewBag.AllTeamsSortedAZ = context.Teams
                .OrderBy(a => a.TeamName);

            ViewBag.AllTeamsSortedZA = context.Teams
                .OrderByDescending(a => a.TeamName);

            ViewBag.LastNameCooper = context.Players
                .Where(a => a.LastName.Contains("Cooper"));

            ViewBag.FirstNameJoshua = context.Players
                .Where(a => a.FirstName.Contains("Joshua"));

            ViewBag.LastNameCooperFirstNameNotJoshua = context.Players
                .Where(a => a.LastName.Contains("Cooper"))
                .Where(b => !b.FirstName.Contains("Joshua"));

            ViewBag.FirstNameOr = context.Players
                .Where(a => a.FirstName.Contains("Alexander") || a.FirstName.Contains("Wyatt"));

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.teamsInAtlanticLeague = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("Atlantic"))
                .Where(team => team.CurrLeague.Sport.Contains("Soccer"));

            ViewBag.bostonPenguinPlayers = context.Players
                .Include(player => player.CurrentTeam)
                .Where(player => player.CurrentTeam.Location.Contains("Boston"))
                .Where(player => player.CurrentTeam.TeamName.Contains("Penguins"));

            ViewBag.collegiatebaseballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("International Collegiate"))
                .Where(team => team.CurrLeague.Sport.Contains("Baseball"));

            ViewBag.amateurfootballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("Amateur"))
                .Where(team => team.CurrLeague.Sport.Contains("Football"));

            ViewBag.allfootballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Sport.Contains("Football"));

            ViewBag.allteamswithsophia = context.Players
                .Include(team => team.CurrentTeam)
                .Where(team => team.FirstName.Contains("Sophia"));

            ViewBag.floresNotRaptors = context.Players
                .Include(team => team.CurrentTeam)
                .Where(team => team.LastName.Contains("Flores"))
                .Where(team => !team.CurrentTeam.TeamName.Contains("Raptors"));

            ViewBag.manitobaCurrentPlayers = context.Players
                .Include(player => player.CurrentTeam)
                .Where(player => player.CurrentTeam.TeamName.Contains("Tiger-Cats"))
                .Where(player => player.CurrentTeam.Location.Contains("Manitoba"));

            // ViewBag.twelveOrMorePlayerTeams = context.Teams
            //     .Include(team => team.)

            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}