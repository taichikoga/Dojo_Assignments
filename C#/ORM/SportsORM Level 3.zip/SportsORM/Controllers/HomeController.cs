﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.WomensLeagues = context.Leagues
                .Where(w => w.Name.Contains("Women"));

            ViewBag.HockeyLeagues = context.Leagues
                .Where(h => h.Sport.Contains("Hockey"));

            ViewBag.NonFootballLeagues = context.Leagues
                .Where(n => !n.Sport.Contains("Football"));

            ViewBag.ConferenceLeagues = context.Leagues
                .Where(c => c.Name.Contains("Conference"));

            ViewBag.AtlanticLeagues = context.Leagues
                .Where(a => a.Name.Contains("Atlantic"));

            ViewBag.DallasTeams = context.Teams
                .Where(d => d.Location.Contains("Dallas"));

            ViewBag.RaptorTeams = context.Teams
                .Where(r => r.TeamName.Contains("Raptors"));

            ViewBag.CityLocations = context.Teams
                .Where(l => l.Location.Contains("City"));

            ViewBag.TCityTeams = context.Teams
                .Where(t => t.TeamName.StartsWith("T"));

            ViewBag.AllTeamsSortedAZ = context.Teams
                .OrderBy(a => a.TeamName);

            ViewBag.AllTeamsSortedZA = context.Teams
                .OrderByDescending(a => a.TeamName);

            ViewBag.LastNameCooper = context.Players
                .Where(a => a.LastName.Contains("Cooper"));

            ViewBag.FirstNameJoshua = context.Players
                .Where(a => a.FirstName.Contains("Joshua"));

            ViewBag.LastNameCooperFirstNameNotJoshua = context.Players
                .Where(a => a.LastName.Contains("Cooper"))
                .Where(b => !b.FirstName.Contains("Joshua"));

            ViewBag.FirstNameOr = context.Players
                .Where(a => a.FirstName.Contains("Alexander") || a.FirstName.Contains("Wyatt"));


            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.teamsInAtlanticLeague = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("Atlantic"))
                .Where(team => team.CurrLeague.Sport.Contains("Soccer"));

            ViewBag.bostonPenguinPlayers = context.Players
                .Include(player => player.CurrentTeam)
                .Where(player => player.CurrentTeam.Location.Contains("Boston"))
                .Where(player => player.CurrentTeam.TeamName.Contains("Penguins"));

            ViewBag.collegiatebaseballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("International Collegiate"))
                .Where(team => team.CurrLeague.Sport.Contains("Baseball"));

            ViewBag.amateurfootballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Name.Contains("Amateur"))
                .Where(team => team.CurrLeague.Sport.Contains("Football"));

            ViewBag.allfootballteams = context.Teams
                .Include(team => team.CurrLeague)
                .Where(team => team.CurrLeague.Sport.Contains("Football"));

            ViewBag.allteamswithsophia = context.Players
                .Include(team => team.CurrentTeam)
                .Where(team => team.FirstName.Contains("Sophia"));

            ViewBag.floresNotRaptors = context.Players
                .Include(team => team.CurrentTeam)
                .Where(team => team.LastName.Contains("Flores"))
                .Where(team => !team.CurrentTeam.TeamName.Contains("Raptors"));

            ViewBag.manitobaCurrentPlayers = context.Players
                .Include(player => player.CurrentTeam)
                .Where(player => player.CurrentTeam.TeamName.Contains("Tiger-Cats"))
                .Where(player => player.CurrentTeam.Location.Contains("Manitoba"));

            ViewBag.twelveOrMorePlayerTeams = context.Teams
                .Include(team => team.AllPlayers)
                .Where(team => team.AllPlayers.Count >= 12);

            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            ViewBag.BaileyTeams = context.Teams
            // .Include(t => t.CurrentPlayers)
            .Include(t => t.AllPlayers)
            .ThenInclude(pt => pt.PlayerOnTeam)
            .Where(t => 
                t.AllPlayers.FirstOrDefault(
                    p => p.PlayerOnTeam.FirstName == "Alexander"
                    && p.PlayerOnTeam.LastName == "Bailey") != null
                );

            ViewBag.ManitobaPlayers = context.Players
            .Include(t => t.AllTeams)
            .ThenInclude(pt => pt.TeamOfPlayer)
            .Where(t => 
                t.AllTeams.FirstOrDefault(
                    p => p.TeamOfPlayer.Location == "Manitoba"
                    && p.TeamOfPlayer.TeamName == "Tiger-Cats") != null
                );

            ViewBag.pastWichitaVikingsPlayers = context.Players
            .Include(t => t.CurrentTeam)
            .Include(t => t.AllTeams)
            .ThenInclude(pt => pt.TeamOfPlayer)
            .Where(ct => !ct.CurrentTeam.Location.Contains("Wichita"))
            .Where(ct => !ct.CurrentTeam.TeamName.Contains("Vikings"))
            .Where(at => 
                at.AllTeams.FirstOrDefault(
                    p => p.TeamOfPlayer.Location == "Wichita"
                    && p.TeamOfPlayer.TeamName == "Vikings") != null
                );

            ViewBag.pastEmilySanchezTeams = context.Teams
            // .Include(t => t.CurrentPlayers)
            .Include(t => t.AllPlayers)
            .ThenInclude(pt => pt.PlayerOnTeam)
            // .Where(ct => !ct.CurrentPlayers.Location.Contains("Wichita"))
            // .Where(ct => !ct.CurrentPlayers.TeamName.Contains("Vikings"))
            .Where(at => 
                at.AllPlayers.FirstOrDefault(
                    p => p.PlayerOnTeam.FirstName == "Emily"
                    && p.PlayerOnTeam.LastName == "Sanchez") != null
                );

            ViewBag.allLeviAtlanticFederationTeams = context.Players
            // .Include(t => t.CurrentPlayers)
            .Include(t => t.AllTeams)
            .ThenInclude(pt => pt.TeamOfPlayer)
            // .Where(ct => !ct.CurrentPlayers.Location.Contains("Wichita"))
            // .Where(ct => !ct.CurrentPlayers.TeamName.Contains("Vikings"))
            .Where(al => al.FirstName == "Levi")
            .Where(at => 
                at.AllTeams.FirstOrDefault(
                    p => p.TeamOfPlayer.CurrLeague.Name.Contains("Atlantic Federation of Amateur Baseball Players")) != null
                );

            return View();
        }

    }
}