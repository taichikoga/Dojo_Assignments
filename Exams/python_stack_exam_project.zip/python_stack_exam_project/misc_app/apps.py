from django.apps import AppConfig


class MiscAppConfig(AppConfig):
    name = 'misc_app'
