from django.apps import AppConfig


class MatchmakingappConfig(AppConfig):
    name = 'MatchmakingApp'
