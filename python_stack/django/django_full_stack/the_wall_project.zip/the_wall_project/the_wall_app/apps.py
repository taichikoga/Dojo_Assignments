from django.apps import AppConfig


class TheWallAppConfig(AppConfig):
    name = 'the_wall_app'
