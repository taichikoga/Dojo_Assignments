from django.apps import AppConfig


class TheWallMessageAppConfig(AppConfig):
    name = 'the_wall_message_app'
