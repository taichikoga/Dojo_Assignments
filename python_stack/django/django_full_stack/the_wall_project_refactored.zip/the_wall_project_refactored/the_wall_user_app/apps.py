from django.apps import AppConfig


class TheWallUserAppConfig(AppConfig):
    name = 'the_wall_user_app'
