from django.apps import AppConfig


class TimeDisplayAppConfig(AppConfig):
    name = 'time_display_app'
