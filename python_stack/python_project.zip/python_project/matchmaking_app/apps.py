from django.apps import AppConfig


class MatchmakingAppConfig(AppConfig):
    name = 'matchmaking_app'
